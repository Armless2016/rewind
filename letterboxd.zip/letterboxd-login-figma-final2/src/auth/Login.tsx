
export default function Login() {
  const navigate = useNavigate();

  return (
    <div className={styles.page}>
      <div className={styles.card}>
        <h1 className={styles.title}>Welcome back</h1>

        <form>
          <input
            type="email"
            placeholder="Enter email"
            className={styles.input}
          />

          <input
            type="password"
            placeholder="Password"
            className={styles.input}
          />

          <div className={styles.row}>
            <label className={styles.remember}>
              <input type="checkbox" />
              Remember me
            </label>

            <span
              className={styles.forgot}
              onClick={() => navigate("/forgot-password")}
            >
              Forgot password?
            </span>
          </div>

          {/* ✅ ВАЖНО: кнопка внутри form */}
          <button type="submit" className={styles.button}>
            Log in
          </button>
        </form>

        {/* divider */}
        <div className={styles.dividerRow}>
          <span></span>
          <p>Sign in with</p>
          <span></span>
        </div>

        {/* social icons */}
        <div className={styles.social}>
          <div className={styles.icon}>
            <i className="fa-brands fa-apple"></i>
          </div>

          <div className={styles.icon}>
            <i className="fa-brands fa-google"></i>
          </div>
        </div>

        <p className={styles.footer}>
          Don’t have an account? <span>Create one</span>
        </p>
      </div>
    </div>
  );
}import styles from "./Login.module.css";
import { useNavigate } from "react-router-dom";





