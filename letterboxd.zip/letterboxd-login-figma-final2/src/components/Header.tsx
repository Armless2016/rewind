import styles from "./Header.module.css";

export default function Header() {
  return (
    <header className={styles.header}>

      {/* LOGO */}
      <div className={styles.logo}>
        <img
          src="/logo.png"
          alt="REWIND"
          className={styles.logoImage}
        />
      </div>

      {/* NAV */}
      <nav className={styles.nav}>
        <a>Films</a>
        <a>Lists</a>
        <a>Members</a>
        <a>Journal</a>
        <a>Account</a>
      </nav>

      {/* SEARCH */}
      <div className={styles.search}>
        <i className="fa-solid fa-magnifying-glass"></i>
      </div>

    </header>
  );
}